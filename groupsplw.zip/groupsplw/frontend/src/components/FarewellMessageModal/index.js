import React, { useState, useEffect, useRef } from "react";

import * as Yup from "yup";
import { Formik, Form, Field } from "formik";
import { toast } from "react-toastify";

import {
  makeStyles,
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  CircularProgress,
} from "@material-ui/core";
import { green } from "@material-ui/core/colors";
import { i18n } from "../../translate/i18n";

import api from "../../services/api";
import toastError from "../../errors/toastError";

import Switch from "@material-ui/core/Switch";

const useStyles = makeStyles((theme) => ({
  root: {
    flexWrap: "wrap",
  },
  textField: {
    marginRight: theme.spacing(1),
    width: "100%",
  },

  btnWrapper: {
    position: "relative",
  },

  buttonProgress: {
    color: green[500],
    position: "absolute",
    top: "50%",
    left: "50%",
    marginTop: -12,
    marginLeft: -12,
  },
  textFarewellMessageContainer: {
    width: "100%",
  },
}));

const FarewellMessageSchema = Yup.object().shape({
  message: Yup.string()
    .required("Required"),
});

const FarewellMessageModal = ({
  open,
  onClose,
  farewellMessageId,
  initialValues,
  onSave,
}) => {
  const classes = useStyles();
  const isMounted = useRef(true);

  const initialState = {
    groupId: "",
    message: "",
  };

  const [farewellMessage, setFarewellMessage] = useState(initialState);
  const [showGroupId, setShowGroupId] = useState(true);

  useEffect(() => {
    return () => {
      isMounted.current = false;
    };
  }, []);

  useEffect(() => {
    const fetchFarewellMessage = async () => {
      if (initialValues) {
        setFarewellMessage((prevState) => {
          return { ...prevState, ...initialValues };
        });
      }

      if (!farewellMessageId) return;

      try {
        const { data } = await api.get(`/farewellMessage/${farewellMessageId}`);
        if (isMounted.current) {
          setFarewellMessage(data);
        }
      } catch (err) {
        toastError(err);
      }
    };

    fetchFarewellMessage();
  }, [farewellMessageId, open, initialValues]);

  const handleClose = () => {
    onClose();
    setFarewellMessage(initialState);
  };

  const handleSaveFarewellMessage = async (values) => {
    try {
      if (showGroupId){
        if (farewellMessageId) {
          await api.put(`/farewellMessage/${farewellMessageId}`, values);
          handleClose();
        } else {
          const { data } = await api.post("/farewellMessage", values);
          if (onSave) {
            onSave(data);
          }
          handleClose();
        }
      }
      if (!showGroupId){
        const updatedValues = {
          groupId: 'all',
          message: values.message
        }
        if (farewellMessageId) {
          await api.put(`/farewellMessage/${farewellMessageId}`, updatedValues);
          handleClose();
        } else {
          const { data } = await api.post("/farewellMessage", updatedValues);
          if (onSave) {
            onSave(data);
          }
          handleClose();
        }
      }
      toast.success(i18n.t("farewellMessageModal.success"));
    } catch (err) {
      toastError(err);
    }
  };

  return (
    <div className={classes.root}>
      <Dialog
        open={open}
        onClose={handleClose}
        maxWidth="sm"
        fullWidth
        scroll="paper"
      >
        <DialogTitle id="form-dialog-title">
          {farewellMessageId
            ? `${i18n.t("farewellMessageModal.title.edit")}`
            : `${i18n.t("farewellMessageModal.title.add")}`}
        </DialogTitle>
        <Formik
          initialValues={farewellMessage}
          enableReinitialize={true}
          validationSchema={FarewellMessageSchema}
          onSubmit={(values, actions) => {
            setTimeout(() => {
              handleSaveFarewellMessage(values);
              actions.setSubmitting(false);
            }, 400);
          }}
        >
          {({ values, errors, touched, isSubmitting }) => (
            <Form>
              <DialogContent dividers>
                <div className={classes.textFarewellMessageContainer}>
                  {showGroupId && (
                    <Field
                      as={TextField}
                      label={i18n.t("farewellMessageModal.form.groupId")}
                      name="groupId"
                      autoFocus
                      error={touched.groupId && Boolean(errors.groupId)}
                      helperText={touched.groupId && errors.groupId}
                      variant="outlined"
                      margin="dense"
                      className={classes.textField}
                      fullWidth
                    />
                  )}
                </div>
                <div className={classes.textFarewellMessageContainer}>
                  <Field
                    as={TextField}
                    label={i18n.t("farewellMessageModal.form.word")}
                    name="message"
                    error={touched.message && Boolean(errors.message)}
                    helperText={touched.message && errors.message}
                    variant="outlined"
                    margin="dense"
                    className={classes.textField}
                    multiline
                    minRows={5}
                    fullWidth
                  />
                </div>
                <div>
                  <Switch
                    checked={!showGroupId}
                    onChange={() => setShowGroupId(!showGroupId)}
                  />
                  <span>{i18n.t("farewellMessageModal.buttons.toggle")}</span>
                </div>
              </DialogContent>
              <DialogActions>
                <Button
                  onClick={handleClose}
                  color="secondary"
                  disabled={isSubmitting}
                  variant="outlined"
                >
                  {i18n.t("farewellMessageModal.buttons.cancel")}
                </Button>
                <Button
                  type="submit"
                  color="primary"
                  disabled={isSubmitting}
                  variant="contained"
                  className={classes.btnWrapper}
                >
                  {farewellMessageId
                    ? `${i18n.t("farewellMessageModal.buttons.okEdit")}`
                    : `${i18n.t("farewellMessageModal.buttons.okAdd")}`}
                  {isSubmitting && (
                    <CircularProgress
                      size={24}
                      className={classes.buttonProgress}
                    />
                  )}
                </Button>
              </DialogActions>
            </Form>
          )}
        </Formik>
      </Dialog>
    </div>
  );
};

export default FarewellMessageModal;
