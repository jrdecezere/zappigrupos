import React, { useState } from "react";

import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Typography from "@material-ui/core/Typography";
import Container from "@material-ui/core/Container";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { toast } from "react-toastify";

import api from "../../services/api";
import { i18n } from "../../translate/i18n.js";
import toastError from "../../errors/toastError";

const useStyles = makeStyles(theme => ({
  root: {
    display: "flex",
    alignItems: "center",
    padding: theme.spacing(8, 8, 3),
  },

  paper: {
    padding: theme.spacing(2),
    display: "flex",
    alignItems: "center",
    marginBottom: 12,
  },

  settingOption: {
    marginLeft: "auto",
  },
  margin: {
    margin: theme.spacing(1),
  },
}));

const SingleGroupParticipantList = () => {
  const classes = useStyles();
  const [whatsappId, setWhatsappId] = useState("");
  const [groupId, setGroupId] = useState("");
  const [formattedParticipants, setFormattedParticipants] = useState([]);

  const handleChangeSetting = async () => {
    const data = {
      groupId: groupId,
      whatsappId: parseInt(whatsappId),
    };

    try {
      const response = await api.post(`/zdgSingleListParticipants/`, data);
      setFormattedParticipants(response.data.participants);
      toast.success(i18n.t("settings.success"));
    } catch (err) {
      toastError(err);
    }
  };

  const handleCopyParticipantsComma = () => {
    const participantsText = formattedParticipants.join(',');
    navigator.clipboard.writeText(participantsText);
    toast.success("Participantes copiados para a área de transferência.");
  };

  const handleCopyParticipantsBreakLine = () => {
    const participantsText = formattedParticipants.join('\n');
    navigator.clipboard.writeText(participantsText);
    toast.success("Participantes copiados para a área de transferência.");
  };

  return (
    <div className={classes.root}>
      <Container className={classes.container} maxWidth="sm">
        <Typography variant="body2" gutterBottom>
          {i18n.t("mainDrawer.listItems.listParticipant")}
        </Typography>
        <Paper className={classes.paper}>
          <TextField
            label={i18n.t("commonLabels.whatsAppID")}
            margin="dense"
            variant="outlined"
            fullWidth
            value={whatsappId}
            onChange={(e) => setWhatsappId(e.target.value)}
          />
        </Paper>
        <Paper className={classes.paper}>
          <TextField
            label={i18n.t("commonLabels.groupId")}
            margin="dense"
            variant="outlined"
            fullWidth
            value={groupId}
            onChange={(e) => setGroupId(e.target.value)}
          />
        </Paper>
        <Paper className={classes.paper}>
          {formattedParticipants.length > 0 && (
            <Container className={classes.container} maxWidth="sm">
              <Typography variant="body2" gutterBottom>
                Participantes:
              </Typography>
              {formattedParticipants.map((group, index) => (
                <Paper key={index} className={classes.paper}>
                  <Typography variant="body1">{group}</Typography>
                </Paper>
              ))}
            </Container>
          )}
        </Paper>
        <Button
          variant="contained"
          color="primary"
          onClick={handleChangeSetting}
          style={{ marginRight: '8px' }}
        >
          {i18n.t("commonLabels.action")}
        </Button>
        <Button
          variant="contained"
          color="primary"
          onClick={handleCopyParticipantsComma}
          style={{ marginRight: '8px' }}
        >
          {i18n.t("commonLabels.copyComma")}
        </Button>
        <Button
          variant="contained"
          color="primary"
          onClick={handleCopyParticipantsBreakLine}
        >
          {i18n.t("commonLabels.copyLine")}
        </Button>
      </Container>
    </div>
  );
};

export default SingleGroupParticipantList;
